# ./examples/
This folder contains examples that can be loaded to program. Just take file from example and put it to programs root directory. Then after running program you can load example via Load button.
> Warning: Save button will override that currently used example.