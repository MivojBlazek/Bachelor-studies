var searchData=
[
  ['generatenewrubbish_112',['generateNewRubbish',['../classScene.html#a988f70270f7ac3c0550cdd1ed63a7397',1,'Scene']]],
  ['getangle_113',['getAngle',['../classRobot.html#a52f709f71fb9f443fe1db383bbdeb012',1,'Robot']]],
  ['getbody_114',['getBody',['../classRobot.html#a25363b077d00981f280d94d472776bdb',1,'Robot']]],
  ['getheight_115',['getHeight',['../classMenu.html#a6ff6f73b6bc203c9968d501af3689e55',1,'Menu::getHeight()'],['../classObstacle.html#a8fcb2867343be78315b0b449bc169a15',1,'Obstacle::getHeight()']]],
  ['getremainingangle_116',['getRemainingAngle',['../classRobot.html#a850744e804a8c2a19a771f122b304894',1,'Robot']]],
  ['getrobot_117',['getRobot',['../classScene.html#a0aa612258d7adfa7a1d29e8a197051d5',1,'Scene']]],
  ['getrobotcount_118',['getRobotCount',['../classRobotList.html#ac5d5a682fcb22138b3e2e05844a4069c',1,'RobotList']]],
  ['getrobotid_119',['getRobotID',['../classRobot.html#a55fae85c11372334cae7181bbc85a2a9',1,'Robot']]],
  ['getrobotsettings_120',['getRobotSettings',['../classRobotList.html#a34dfc3f6548388e94a7e5143f106f475',1,'RobotList']]],
  ['getrubbishid_121',['getRubbishID',['../classRubbish.html#a21627979515f7f7882bba32d2edc5d63',1,'Rubbish']]],
  ['getsimulationspeed_122',['getSimulationSpeed',['../classMenu.html#a7be04832cb20745ad137bfc351eb8454',1,'Menu']]],
  ['getwidth_123',['getWidth',['../classMenu.html#af5f7a00ebf7a9a583592bb38a0361001',1,'Menu::getWidth()'],['../classObstacle.html#a1b85fc3d991073fd16809f27169351ff',1,'Obstacle::getWidth()']]]
];
