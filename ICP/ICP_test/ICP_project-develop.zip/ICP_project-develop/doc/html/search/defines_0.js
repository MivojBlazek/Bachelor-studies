var searchData=
[
  ['time_5fto_5fspawn_5frubbish_168',['TIME_TO_SPAWN_RUBBISH',['../scene_8h.html#aef5163ea52f5bdf222c0b361303b3e93',1,'scene.h']]]
];
