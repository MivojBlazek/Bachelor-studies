var searchData=
[
  ['robotid_165',['robotID',['../structRobotSettings.html#ae2028209e4710057c9b596ce6022fd2c',1,'RobotSettings']]],
  ['rotation_166',['rotation',['../structRobotSettings.html#ac228c554397ce58db0805bbcda150037',1,'RobotSettings']]],
  ['rotationdirection_167',['rotationDirection',['../structRobotSettings.html#a3d0e79de416ff1348f01ac7eac9070bb',1,'RobotSettings']]]
];
