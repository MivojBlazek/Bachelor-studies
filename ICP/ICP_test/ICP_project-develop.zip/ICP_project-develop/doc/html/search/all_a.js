var searchData=
[
  ['paint_37',['paint',['../classObstacle.html#a18d0cf667646987f5532e50bfb91c160',1,'Obstacle::paint()'],['../classRubbish.html#a464e932eac6d95c0e3a06180bf75b9a8',1,'Rubbish::paint()']]],
  ['pause_38',['pause',['../classScene.html#abb5d29d3af5354bd22b7aaba76459834',1,'Scene']]]
];
