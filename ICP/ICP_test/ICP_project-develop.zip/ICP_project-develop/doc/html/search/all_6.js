var searchData=
[
  ['isplayer_21',['isPlayer',['../classMenu.html#ac00e435730ab8881c49e1a7ae34586fb',1,'Menu::isPlayer()'],['../classScene.html#acac933955165045d52983d62b795f0cb',1,'Scene::isPlayer()']]]
];
