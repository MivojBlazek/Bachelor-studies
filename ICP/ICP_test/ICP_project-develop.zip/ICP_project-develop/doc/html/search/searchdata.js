var indexSectionsWithContent =
{
  0: "abcdfgilmoprstu~",
  1: "mors",
  2: "mors",
  3: "abcfgilmoprstu~",
  4: "dr",
  5: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

