ICP project program

Authors:
    Michal Blažek    <xblaze38>
    Kryštof Michálek <xmicha94>
