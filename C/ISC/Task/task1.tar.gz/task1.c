#include <stdio.h>


int main(void)
{
	printf("Muj login je ondrej.\n");

	return 0;
}
