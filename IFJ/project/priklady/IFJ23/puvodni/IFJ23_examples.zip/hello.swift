// Hello World example in IFJ23
// run it on Merlin by: swift <(cat hello.swift ifj23.swift)

func hlavni_program(year y : Int)  {
  write("Hello from IFJ", y, "\n")
}

hlavni_program(year:23)
hlavni_program(year: 24) // pozdrav z budoucnosti

