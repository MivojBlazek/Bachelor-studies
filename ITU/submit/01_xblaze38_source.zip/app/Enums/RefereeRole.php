<?php

namespace App\Enums;

enum RefereeRole: string
{
    case Main = 'main';
    case Line = 'line';
}
