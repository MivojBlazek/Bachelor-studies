# Demo konstrukce síťové komunikace v Common LISP
Tato sada souborů demonstruje různé způsoby implementace klient-server v jazyce Common LISP.
