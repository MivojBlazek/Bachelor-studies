# Demo konstrukce síťové komunikace v C#
Tato sada souborů demonstruje různé způsoby implementace klient-server v jazyce C#.
